This is an IBus engine for Shortn.



Development happens [on github](https://github.com/ibus-shortn),
table release tarballs can be found in
[the download section](http://shortn.io/downloads/ibus-shortn/) of
our website.


## Legalities

IBus Shortn is offered under the terms of the
[GNU General Public License, either version 3 or any later version](http://www.gnu.org/licenses/lgpl.html).

We won't ask you to sign a copyright assignment or any other kind of silly and
tedious legal document, so just send us patches and/or pull requests!
